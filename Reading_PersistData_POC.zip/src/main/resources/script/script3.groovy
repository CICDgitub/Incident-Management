/*
Developer - Krishna Chauhan
Date: 11-Sep-2023
This script populated the property url based on MessageStoreId
*/
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*
def Message processData(Message message) {
    //Body
    def body = message.getBody(java.lang.String);
    def slurper = new XmlSlurper() //Creating the object
    def xmlPayload = slurper.parseText(body)  //Parsing the body
   
  def pmap = message.getProperties() 
  def url
  def MessageStoreId = pmap.get("MessageStoreId")
   
   for(int i=0;i<xmlPayload.entry.size();i++)
   {    
       if (MessageStoreId == xmlPayload.entry[i].properties.MessageStoreId.text())
       {
        url = xmlPayload.entry[i].id.text() 
        message.setProperty("url", url)//setting URL
        break
       }
       else
       message.setProperty("url", "invalid")
   }
  
  // message.setBody("url", xmlPayload.entry[0].properties.MessageStoreId.text())
    return message;
}